<?php

class Webforms_Version_Helper {

    public static $version = '1.6.0';
    public static $patch = '14010925';

    public static function getVersion()
    {
        return self::$version;
    }
    
    public static function getPatch()
    {
        return self::$patch;
    }

}