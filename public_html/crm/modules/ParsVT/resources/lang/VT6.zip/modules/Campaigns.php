<?php
/*+***********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 *************************************************************************************/
/*************************************************************************************
 * Filename: Campaigns.php
 * Description:  Defines the Persian (Farsi - فارسی) language pack for the base application.
 * تیم پارس ویتایگر - پاییز 1395/autumn 2016
 * تمام حقوق محفوظ است.
 * Contributor: AWEB Information Technology CO - www.awebict.net
 * Author: Hamid Rabiei <hamid.rabiei[@]hotmail[dot]com>
**************************************************************************************/
$languageStrings = array (
  'Actual Cost' => 'بهای واقعی',
  'Actual Response Count' => 'مقدار دریافتی واقعی',
  'Actual ROI' => 'نرخ بازگشت سرمایه ی واقعی',
  'Actual Sales Count' => 'تعداد فروش واقعی',
  'Advertisement' => 'آگهی تبلیغاتی',
  'Average' => 'متوسط',
  'Banner Ads' => 'تبلیغات بنر',
  'Budget Cost' => 'هزینه در نظر گرفته شده',
  'Campaign Name' => 'نام کمپین تبلیغاتی',
  'Campaign No' => 'شماره کمپین تبلیغاتی',
  'Campaigns' => 'کمپین های تبلیغاتی',
  'Campaign Status' => 'وضعیت کمپین تبلیغاتی',
  'Campaign Type' => 'نوع کمپین تبلیغاتی',
  'Cancelled' => 'لغو شده',
  'Completed' => 'تکمیل شده',
  'Contacted - Never Contact Again' => 'تماس گرفته شد - هرگز دوباره تماس گرفته نشود',
  'Contacted - Successful' => 'تماس گرفته شد - موفقیت آمیز',
  'Contacted - Unsuccessful' => 'تماس گرفته شد - نا موفق',
  'Direct Mail' => 'پست مستقیم',
  'Excellent' => 'عالی',
  'Expected Response Count' => 'مقدار دریافتی مورد انتظار',
  'Expected Response' => 'پاسخ مورد انتظار',
  'Expected Revenue' => 'درآمد مورد انتظار',
  'Expected ROI' => 'نرخ بازگشت سرمایه ی مورد انتظار',
  'Expected Sales Count' => 'تعداد فروش مورد انتظار',
  'Good' => 'خوب',
  'Inactive' => 'غیر فعال',
  'LBL_ADD_RECORD' => 'افزودن کمپین تبلیغاتی',
  'LBL_CAMPAIGN_INFORMATION' => 'اطلاعات کمپین تبلیغاتی',
  'LBL_EXPECTATIONS_AND_ACTUALS' => 'انتظارات و واقعیت ها',
  'LBL_RECORDS_LIST' => 'لیست کمپین های تبلیغاتی',
  '--None--' => '--هیچ--',
  'Num Sent' => 'تعداد ارسالی',
  'Others' => 'سایر',
  'Planning' => 'در حال برنامه ریزی',
  'Poor' => 'ضعیف',
  'Product' => 'محصول',
  'Referral Program' => 'کمپین تبلیغاتی',
  'SINGLE_Campaigns' => 'کمپین تبلیغاتی',
  'Sponsor' => 'پشتیبان',
  'Target Audience' => 'جامعه هدف تبلیغات',
  'TargetSize' => 'وسعت بازار هدف',
  'Telemarketing' => 'بازاریابی تلفنی',
  'Webinar' => 'کنفرانس آنلاین',
  'Active' => 'فعال',
);

$jsLanguageStrings = array (
  'JS_LBL_ARE_YOU_SURE_YOU_WANT_TO_ADD_THIS_FILTER' => 'آیا از افزودن این رکورد فیلتر اطمینان دارید؟',
);