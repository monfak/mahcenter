<?php
/*+***********************************************************************************
 * The contents of this file are subject to the vtiger CRM Public License Version 1.0
 * ("License"); You may not use this file except in compliance with the License
 * The Original Code is:  vtiger CRM Open Source
 * The Initial Developer of the Original Code is vtiger.
 * Portions created by vtiger are Copyright (C) vtiger.
 * All Rights Reserved.
 *************************************************************************************/
/*************************************************************************************
 * Filename: Settings/Payments.php
 * Description:  Defines the Persian (Farsi - فارسی) language pack for the base application.
 * تیم پارس ویتایگر - پاییز 1395/autumn 2016
 * تمام حقوق محفوظ است.
 * Contributor: AWEB Information Technology CO - www.awebict.net
 * Author: Hamid Rabiei <hamid.rabiei[@]hotmail[dot]com>
**************************************************************************************/
$languageStrings = array (
  'LBL_RIGHT_CLICK_COPY' => 'راست کلیک کنید و کپی کنید',
);

$jsLanguageStrings = array (
  'JS_DELETED_SUCCESSFULLY' => 'با موفقیت حذف شد',
  'JS_SAVED_SUCCESSFULLY' => 'با موفقیت ذخیره شد',
);